package com.example.practica5;

import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Label;

public interface HelloController {
    Parent getContent();

}