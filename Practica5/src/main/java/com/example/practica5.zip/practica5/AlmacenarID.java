package com.example.practica5;

public class AlmacenarID {
    private static int id;

    int getId(){
        return this.id = id;
    }

    void setId(int id){
        this.id=id;
    }
}
